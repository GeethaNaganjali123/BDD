package selinium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FreeCRMLogin {
private static WebDriver driver;
	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\gnimmala\\Desktop\\BDDMODULE\\chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 driver.navigate().to("https://freecrm.com/");
		 WebElement element=driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/div[2]/div/div[2]/ul/a/span[2]"));
		 element.click();
		 Thread.sleep(2000);
		 WebElement element2=driver.findElement(By.name("email"));
		 element2.sendKeys("java4excellence@gmail.com");
		 
		 driver.findElement(By.name("password")).sendKeys("Qwz123456789@");
		 driver.findElement(By.xpath("//*[@id=\"ui\"]/div/div/form/div/div[3]")).click();
		 Thread.sleep(5000);
		//driver.close();
		 
		 
		 
        
	}

}
